// ProgressTracking_UseCase_Testing.java
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProgressTracking_UseCase_Testing {

    // 1) Valid weight & valid body fat
    @Test
    void progress_TC1_Valid_All() {
        assertEquals(
                "Progress recorded",
                ProgressTracking.recordProgress("150", "20")
        );
    }

    // 2) Valid weight, invalid body fat (out of range)
    @Test
    void progress_TC2_ValidWeight_InvalidBodyFat() {
        assertEquals(
                "Invalid body fat percentage",
                ProgressTracking.recordProgress("150", "40")
        );
    }

    // 3) Valid weight, exceptional body fat (non-numeric)
    @Test
    void progress_TC3_ValidWeight_ExceptionalBodyFat() {
        assertEquals(
                "Invalid body fat percentage",
                ProgressTracking.recordProgress("150", "abc")
        );
    }

    // 4) Invalid weight (out of range), valid body fat
    @Test
    void progress_TC4_InvalidWeight_ValidBodyFat() {
        assertEquals(
                "Invalid weight",
                ProgressTracking.recordProgress("600", "20")
        );
    }

    // 5) Exceptional weight (null), valid body fat
    @Test
    void progress_TC5_ExceptionalWeight_ValidBodyFat() {
        assertEquals(
                "Invalid weight",
                ProgressTracking.recordProgress(null, "20")
        );
    }
}
