// ProgressTracking.java
public class ProgressTracking {

    /**
     * Records a progress update given weight and body fat percentage strings.
     * Returns a success message or the first validation error encountered.
     */
    public static String recordProgress(String weightStr, String bodyFatStr) {
        if (!isValidWeight(weightStr)) {
            return "Invalid weight";
        }
        if (!isValidBodyFat(bodyFatStr)) {
            return "Invalid body fat percentage";
        }
        return "Progress recorded";
    }

    public static boolean isValidWeight(String weightStr) {
        if (weightStr == null) return false;
        try {
            int weight = Integer.parseInt(weightStr);
            return weight >= 0 && weight <= 500;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean isValidBodyFat(String bodyFatStr) {
        if (bodyFatStr == null) return false;
        try {
            int bf = Integer.parseInt(bodyFatStr);
            return bf >= 0 && bf <= 32;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
